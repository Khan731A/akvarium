package baza;

import java.util.Scanner;
import java.sql.*;

import static baza.notMain.statement;

public class Main {
    static int money = 0;
    static int normfish = 0;
    static int piran = 0;
    static int snake = 0;
    static int nesnake = 0;
    public static void Input(int num) throws SQLException {
        Scanner sc = new Scanner(System.in);
        int n;
        switch (num) {
            case 1:
                System.out.println("Choose type of fish:");
                ResultSet fish = statement.executeQuery("SELECT * FROM ribki.fish");
                while (fish.next()) {
                    System.out.println("ID: " + fish.getInt(1) + ", " +
                            "Name: " + fish.getString(2) + ", " +
                            "Cost: " + fish.getInt(3) + "$.");
                }
                n = sc.nextInt();
                System.out.println("How many do you want?");
                int num1 = sc.nextInt();
                switch (n) {
                    case 1:
                        if(piran>0){
                            System.out.println("You can't buy this fish with piranhas.");
                        }
                        else {
                            money += 29 * num1;
                            normfish+=1;
                        }
                        break;
                    case 2:
                        if(piran>0){
                            System.out.println("You can't buy this fish with piranhas.");
                        }
                        else {
                            money += 19 * num1;
                            normfish+=1;
                        }
                        break;
                    case 3:
                        if(piran>0){
                            System.out.println("You can't buy this fish with piranhas.");
                        }
                        else {
                            money += 89 * num1;
                            normfish+=1;
                        }
                        break;
                    case 4:
                        if(piran>0){
                            System.out.println("You can't buy this fish with piranhas.");
                        }
                        else {
                            money += 8 * num1;
                            normfish+=1;
                        }
                        break;
                    case 5:
                        if(piran>0){
                            System.out.println("You can't buy this fish with piranhas.");
                        }
                        else {
                            money += 15 * num1;
                            normfish+=1;
                        }
                        break;
                    case 6:
                        if(normfish>0){
                            System.out.println("You can't buy piranhas with other fishes.");
                        }
                        else {
                            money += 30 * num1;
                            piran+=1;
                        }
                        break;
                }
                break;
            case 2:
                System.out.println("Choose type of reptile:");
                ResultSet reptiels = statement.executeQuery("SELECT * FROM ribki.reptiels");
                while (reptiels.next()) {
                    System.out.println("ID: " + reptiels.getInt(1) + ", " +
                            "Name: " + reptiels.getString(2) + ", " +
                            "Cost: " + reptiels.getInt(3) + "$.");
                }
                n = sc.nextInt();
                System.out.println("How many do you want?");
                int num2 = sc.nextInt();
                switch (n) {
                    case 1:
                        if(snake>0){
                            System.out.println("You can't buy this reptile with snakes.");
                        }
                        else {
                            money += 20 * num2;
                            nesnake+=1;
                        }
                        break;
                    case 2:
                        if(snake>0){
                            System.out.println("You can't buy this reptile with snakes.");
                        }
                        else {
                            money += 15 * num2;
                            nesnake+=1;
                        }
                        break;
                    case 3:
                        if(snake>0){
                            System.out.println("You can't buy this reptile with snakes.");
                        }
                        else {
                            money += 50 * num2;
                            nesnake+=1;
                        }
                        break;
                    case 4:
                        if(nesnake>0){
                            System.out.println("You can't buy snakes with other reptiles.");
                        }
                        else {
                            money += 50 * num2;
                            snake+=1;
                        }
                        break;
                    case 5:
                        if(snake>0){
                            System.out.println("You can't buy this reptile with snakes.");
                        }
                        else {
                            money += 20 * num2;
                            nesnake+=1;
                        }
                        break;
                }
                break;
            default:
                break;
        }
    }

    public static void Aquarium() throws SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose aquarium:");
        ResultSet aquariums = statement.executeQuery("SELECT * FROM ribki.aquariums");
        while(aquariums.next()){
            System.out.println("ID: "+aquariums.getInt(1)+", Type: "+aquariums.getString(2)
            +", Volume: "+aquariums.getInt(3)+", Cost: "+aquariums.getInt(4));
        }
        int num3 = sc.nextInt();
        switch (num3){
            case 1: money+=200; break;
            case 2: money+=120; break;
            case 3: money+=80; break;
            case 4: money+=30; break;
            case 5: money+=15; break;
        }
    }

    public static void Filters(int num) throws SQLException {
        Scanner sc = new Scanner(System.in);
        if(num!=1){
            System.out.println("You don't need a filter.");
        }
        else {
            System.out.println("Choose filter:");
            ResultSet filters = statement.executeQuery("SELECT * FROM ribki.filters");
            while (filters.next()) {
                System.out.println("ID: " + filters.getInt(1) + ", Name: " + filters.getString(2)
                        + ", Num: " + filters.getInt(3) + ", Cost: " + filters.getInt(4));
            }
            int num4 = sc.nextInt();
            switch (num4) {
                case 1:
                    money += 370;
                    break;
                case 2:
                    money += 240;
                    break;
                case 3:
                    money += 170;
                    break;
                case 4:
                    money += 150;
                    break;
                case 5:
                    money += 140;
                    break;
            }
        }
    }

    public static void Toys() throws SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose toy:");
        ResultSet toys = statement.executeQuery("SELECT * FROM ribki.toys");
        while(toys.next()){
            System.out.println("ID: "+toys.getInt(1)+", Form: "+toys.getString(2)
                    +", Cost: "+toys.getInt(3));
        }
        int num5 = sc.nextInt();
        switch (num5){
            case 1: money+=10; break;
            case 2: money+=15; break;
            case 3: money+=20; break;
            case 4: money+=15; break;
        }
    }

    public static void Sand() throws SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose type of sand:");
        ResultSet sand = statement.executeQuery("SELECT * FROM ribki.sand");
        while(sand.next()){
            System.out.println("ID: "+sand.getInt(1)+", Type: "+sand.getString(2)
                    +", Mass: "+sand.getInt(3) + ", Cost: "+sand.getInt(4)+"$");
        }
        int num7 = sc.nextInt();
        switch (num7){
            case 1: money+=1; break;
            case 2: money+=3; break;
            case 3: money+=5; break;
            case 4: money+=3; break;
            case 5: money+=4; break;
        }
    }

    public static void Feed(int num) throws SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose feed:");
        ResultSet aquariums = statement.executeQuery("SELECT * FROM ribki.feed");
        while(aquariums.next()){
            System.out.println("ID: "+aquariums.getInt(1)+", Name: "+aquariums.getString(2)
                    +", Mass: "+aquariums.getInt(3)+", Cost: "+aquariums.getInt(4));
        }
        int num6 = sc.nextInt();
        switch (num6){
            case 1:
                if(num!=1){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=25;
                }
                break;
            case 2:
                if(num!=1){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=15;
                }
                break;
            case 3:
                if(num!=1){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=10;
                }
                break;
            case 4:
                if(num!=1){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=5;
                }
                break;
            case 5:
                if(num!=2){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=13;
                }
                break;
            case 6:
                if(num!=2){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=16;
                }
                break;
            case 7:
                if(num!=2){
                    System.out.println("You can't buy this.");
                    break;
                }
                else{
                    money+=7;
                }
                break;
        }
    }
    public static void main(String[] args) throws SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to AquaShop\n" +
                "Choose what type of pet you want to buy:\n" +
                "1.Fish\n2.Reptiles\n3.I don't wanna anything");
        int num = sc.nextInt();
        Input(num);
        Aquarium();
        Filters(num);
        Toys();
        Sand();
        Feed(num);
        int num2 = 0;
        while (num2 != 2) {
            System.out.println("Wanna buy something else?\n1.Yes\n2.No");
            num2 = sc.nextInt();
            if(num2==1){
                Input(num);
            }
        }
        System.out.println("Total cost of you purchase: "+money+"$");
        System.out.println("Goodbye!");
    }
}